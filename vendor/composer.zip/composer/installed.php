<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => NULL,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => NULL,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'midtrans/midtrans-php' => array(
            'pretty_version' => '2.6.2',
            'version' => '2.6.2.0',
            'reference' => '8ed7fc58ff1ababe675da17acf8233f4028eb3be',
            'type' => 'library',
            'install_path' => __DIR__ . '/../midtrans/midtrans-php',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
